export const quizDifficulty = {
  easy: 10,
  medium: 20,
  hard: 30,
};
