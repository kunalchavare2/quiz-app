export const db_username = "kunalchavare2";
export const db_password = "Cyber%40hack26";

export const db_database = "Music_app_data";

export const ACCESS_TOKEN_SECRET =
  "a00e366e93dd11092837262a40c7322a380bb0ed4302ed083682cd0c112234016d8abac92f4cfa79789d57feebf9830c672786b6d6030da492faba32c4ceef28";
export const REFRESH_TOKEN_SECRET =
  "53d7eecf5a42664f571d5afcf31061bed9e8c1cfe9bf598bc5bdc30bf2d603fc059f5d094952a5979291cd3357ffcdde272c103eb8728b9c83d6eda46cd0234f";
